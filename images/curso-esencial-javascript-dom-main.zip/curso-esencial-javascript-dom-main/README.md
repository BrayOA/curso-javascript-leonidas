# Curso esencial de JavaScript y el DOM

Domina los conceptos esenciales desde sentencias hasta asincronía en JavaScript 
<p>
  <a href="https://leonidasesteban.com/cursos/javascript">
    Ir al curso
  </a>
</p>

<a href="https://leonidasesteban.com/cursos/javascript">
 <img alt="Curso esencial de JavaScript y el DOM" src="https://github.com/LeonidasEsteban/curso-esencial-javascript-dom/blob/main/curso-de-javascript.png?raw=true">
</a>
