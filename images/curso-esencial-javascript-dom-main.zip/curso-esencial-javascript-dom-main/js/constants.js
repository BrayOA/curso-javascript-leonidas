export const API_KEY = '1f102dd2838093c8fae6382dc4c7fb00'
export const BASE_API = 'https://api.openweathermap.org/data/2.5/'

export const weatherConditionsCodes = {
  2: 'rainy',
  3: 'drizzle',
  5: 'rainy',
  6: 'drizzle',
  7: 'cloudy',
  8: 'clean',
}